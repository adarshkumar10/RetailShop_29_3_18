var express = require('express');
var bodyParser = require('body-parser')


var app = express();
app.set('view engine', 'ejs');
var ObjectID = require('mongodb').ObjectID;
var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017/';
var router = express.Router()

router.use(bodyParser.urlencoded({
    extended: true
}));

router.use(express.static('public'));

router.use(bodyParser.json());
app.use(router);

router.get('/', function (req, res) {
    res.render('pages/adminHome');
    var collectionName = "SCID";
    var flag = createAutoIncrementCounters(collectionName);
    if (flag == 1) {
        console.log('Collection created ' + collectionName);
    }
});
router.get('/addProduct', function (req, res) {
    res.render('pages/addProduct');
});
router.get('/addCategories', function (req, res) {
    res.render('pages/addCategories');
});

router.get('/Orders', function (req, res) {
    res.render('pages/Orders');
});

function createAutoIncrementCounters(ID_NAME) {
    // console.log(dbs);
    console.log('+++++++++++++++++++++++++++++++++++++++')
    /*dbs.retailDB.collection('superCategory').find({}).toArray(function (err, superCategories) {
        if (err){
            console.log(err.stack);
        } else{
            console.log(superCategories);
        }
       

    });
    */
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("reatailshop");
        dbo.collection("superCategory").find({}).toArray(function (err, result) {
            if (err) throw err;
            console.log(result);
            db.close();
        });
    });
}

router.post('/addSuperCategory', function (req, res) {
    MongoClient.connect(url, function (err, db) {
        var dbo = db.db('retailshop');
        console.log(req.params.name_SCID)
        var obj = {
            SC_ID: req.params.name_SCID,
            SC_NAME: req.params.name_SCNAME,
            createdDate: req.params.SC_CDATE,
            updatedDate: req.params.SC_UDATE
        };
        console.log(obj);
        dbo.collection('superCategory').insertOne(obj, function (err, result) {
            if (err) {
                res.send({
                    result: "error"
                })
            } else {
                console.log("1 documemnt inserted at" + new Date());
                res.send({
                    result: "Added"
                })
                db.close();
            }
        });

    });
});
module.exports = router;