var express = require('express');

var bodyParser = require('body-parser');
var app = express();
var ObjectID = require('mongodb').ObjectID;
var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017/';
app.set('view engine', 'ejs');
app.use(express.static('public'));

//var initDatabases = require('./public/js/dbConfig.js')
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));



//var adminRouter = require('./routes/adminRoute');
var userRouter = require('./routes/userRoute');
/*
initDatabases(function (err, dbs) {
    if (err) {
        console.log('Failed to make Database Connection to RetailShop');
        console.log(err);
    } else {
        
        //app.use('/admin',adminRouter);
        userRouter(app, dbs);
    }
});
*/
app.get('/admin', function (req, res) {
    res.render('pages/adminHome');
   
});

app.get('/addProduct', function (req, res) {
    res.render('pages/addProduct');
});
app.get('/addCategories', function (req, res) {
    res.render('pages/addCategories');
});

app.get('/Orders', function (req, res) {
    res.render('pages/Orders');
});
/*
function createAutoIncrementCounters(ID_NAME) {
    // console.log(dbs);
    console.log('+++++++++++++++++++++++++++++++++++++++')
    /*dbs.retailDB.collection('superCategory').find({}).toArray(function (err, superCategories) {
        if (err){
            console.log(err.stack);
        } else{
            console.log(superCategories);
        }
       

    });
    
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("reatailshop");
        dbo.collection("superCategory").find({}).toArray(function (err, result) {
            if (err) throw err;
            console.log(result);
            db.close();
        });
    });
}*/

app.post('/getSuperCategory', function(req, res){
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("retailshop");
        dbo.collection("superCategory").find({}).toArray(function (err, result) {
            if (err) throw err;
            res.send({response:result});
            db.close();
        });
    });
});

app.post('/getCategory', function(req,res){
    MongoClient.connect(url, function(err,db){
        if (err) throw err;
       var dbo = db.db('retailshop');
        var superCategory = req.body.inputData1;
        dbo.collection("category").find({"SC_NAME":superCategory}).toArray(function (err, result) {
            if (err) throw err;
            res.send({response:result});
            db.close();
        });
        
    });
});

app.post('/getSubCategory', function(req,res){
    MongoClient.connect(url, function(err,db){
        if (err) throw err;
       var dbo = db.db('retailshop');
        var superCategory = req.body.inputData1;
        var category = req.body.inputData2;
        console.log(superCategory+"------"+category)
        dbo.collection("subcategory").find({$and:[{"SC_NAME":superCategory},{"C_NAME":category}]}).toArray(function (err, result) {
            if (err) throw err;
            res.send({response:result});
            db.close();
        });
        
    });
});
app.post('/addCategory', function(req,res){
   MongoClient.connect(url, function (err, db) {
        var dbo = db.db('retailshop');
        var obj = {
            C_ID: req.body.name_CID,
            C_NAME: req.body.name_CNAME,
            SC_NAME:req.body.S_name_CNAME,
            createdDate: req.body.C_CDATE,
            updatedDate: req.body.C_UDATE,
            show: req.body.showCat
        };
        dbo.collection('category').insertOne(obj, function (err, result) {
            if (err) {
                res.send({
                    result: "error"
                })
            } else {
                console.log("1 documemnt inserted at" + new Date());
                res.send({
                    result: "Added"
                })
                db.close();
            }
        });
   });
    
});

app.post('/addSubCategory', function(req,res){
   MongoClient.connect(url, function (err, db) {
        var dbo = db.db('retailshop');
        var obj = {
            subC_ID: req.body.name_subCID,
            subC_NAME: req.body.subCName,
            SC_NAME:req.body.sub_NAMESC,
            C_NAME:req.body.sub_NAMEC,
            createdDate: req.body.sub_CDATE,
            updatedDate: req.body.sub_UDATE,
            show: req.body.showSubCat
        };
        dbo.collection('subcategory').insertOne(obj, function (err, result) {
            if (err) {
                res.send({
                    result: "error"
                })
            } else {
                console.log("1 documemnt inserted at" + new Date());
                res.send({
                    result: "Added"
                })
                db.close();
            }
        });
   });
    
});
app.post('/addSuperCategory', function (req, res) {
    MongoClient.connect(url, function (err, db) {
        var dbo = db.db('retailshop');
        var obj = {
            SC_ID: req.body.name_SCID,
            SC_NAME: req.body.name_SCNAME,
            createdDate: req.body.SC_CDATE,
            updatedDate: req.body.SC_UDATE,
            show: req.body.show
        };
        dbo.collection('superCategory').insertOne(obj, function (err, result) {
            if (err) {
                res.send({
                    result: "error"
                })
            } else {
                console.log("1 documemnt inserted at" + new Date());
                res.send({
                    result: "Added"
                })
                db.close();
            }
        });

    });
});

app.post('/addCategory', function (req, res) {
    MongoClient.connect(url, function (err, db) {
        if (err) {
            console.log(err);
        } else {
            console.log(req.body.name_CID);
        }

    });
})
var port = 8080;
app.listen(port, function () {
    console.log('Server is running on port:', port);

});

/*
app.get('/', function(req, res) {
    res.render('pages/index');
});

var port = 8080;
app.listen(port);
console.log('\nApplication ruing on port'+port);
app.get('/registered', function(req, res) {
    res.render('pages/registered');
});

app.get('/groceries', function(req, res) {
    res.render('pages/groceries');
});

app.get('/adminHome', function(req, res) {
    res.render('pages/adminHome');
});

app.get('/login', function(req, res) {
    res.render('pages/login');
});

app.get('/about', function(req, res) {
    res.render('pages/about');
});

app.get('/gourmet', function(req, res) {
    res.render('pages/gourmet');
});

app.get('/household', function(req, res) {
    res.render('pages/household');
});

app.get('/offers', function(req, res) {
    res.render('pages/offers');
});

app.get('/offers', function(req, res) {
    res.render('pages/offers');
});

app.get('/packagedfoods', function(req, res) {
    res.render('pages/packagedfoods');
});

app.get('/personalcare', function(req, res) {
    res.render('pages/personalcare');
});

app.get('/products', function(req, res) {
    res.render('pages/products');
});
app.get('/short-codes', function(req, res) {
    res.render('pages/short-codes');
});


app.get('/single', function(req, res) {
    res.render('pages/single');
});

app.get('/faq', function(req, res) {
    res.render('pages/faq');
});

app.get('/checkout', function(req, res) {
    res.render('pages/checkout');
});

app.get('/contact', function(req, res) {
    res.render('pages/contact');
});

app.get('/beverages', function(req, res) {
    res.render('pages/beverages');
});
*/