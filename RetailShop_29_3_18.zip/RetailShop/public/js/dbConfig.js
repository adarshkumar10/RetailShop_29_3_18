var async = require('async');
    var MongoClient = require('mongodb').MongoClient;
var RETAILSHOP_URL = 'mongodb://localhost:27017/reatailshop';

var database = {
    retailDB : async.apply(MongoClient.connect, RETAILSHOP_URL)
};

console.log('Connected to DB RetailShop');
module.exports= function(cb){
    async.parallel(database, cb);
}