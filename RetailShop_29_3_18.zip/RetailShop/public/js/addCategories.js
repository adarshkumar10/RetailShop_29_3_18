var superCategoryHeader = [
    {
        name: "SuperCategoryID"
    },
    {
        name: "SuperCategoryName"
    },
    {
        name: "CreatedDate"
    },
    {
        name: "UpdateDate"
    },
    {
        name: "Show"
    }

];

var categoryHeader = [
    {
        name: "CategryID"
    },
    {
        name: "CategryName"
    },
    {
        name: "SuperCategoryName"
    },
    {
        name: "CreatedDate"
    },
    {
        name: "UpdateDate"
    },
    {
        name: "Show"
    }
];

var subCategoryHeader = [
    {
        name: "SubCatgeoryID"
    },
    {
        name: "SubCatgeoryName"
    },
    {
        name: "SuperCatgeory"
    },
    {
        name: "Catgeory"
    },
    {
        name: "CreatedDate"
    },
    {
        name: "UpdateDate"
    },
    {
        name: "Show"
    }
]

function createTable(table, type, data, header) {
    table.empty();
    console.log(type)
    console.log(data.response.length);
    var head = $("<tr></tr>");
    for (var i = 0; i < header.length; i++) {
        var th = $("<th class='w3-grey'>" + header[i].name + "</th>");
        head.append(th);
    }
    head.append($($("<th class='w3-grey'>Update</th>")));
    head.append($($("<th class='w3-grey'>Delete</th>")));
    table.append(head);
    if (type == "/getSuperCategory") {
        for (var i = 0; i < data.response.length; i++) {
            var tr = $("<tr id='" + data.response[i]._id + "'></tr>");
            tr.append($($("<td>" + data.response[i].SC_ID + "</td>")));
            tr.append($($("<td>" + data.response[i].SC_NAME + "</td>")));
            tr.append($($("<td>" + data.response[i].createdDate + "</td>")));
            tr.append($($("<td>" + data.response[i].updatedDate + "</td>")));
            tr.append($($("<td>" + data.response[i].show + "</td>")));

            table.append(tr);
            tr.append($($("<td><button class='update w3-button w3-tiny w3-blue w3-disabled'>Update</button></td>")));
            tr.append($($("<td><button class='delete w3-button w3-tiny w3-red w3-disabled'>Delete</button></td>")));
        }
    }
    if (type == "/getCategory") {
        for (var i = 0; i < data.response.length; i++) {
            var tr = $("<tr id='" + data.response[i]._id + "'></tr>");
            tr.append($($("<td>" + data.response[i].C_ID + "</td>")));
            tr.append($($("<td>" + data.response[i].C_NAME + "</td>")));
            tr.append($($("<td>" + data.response[i].SC_NAME + "</td>")));
            tr.append($($("<td>" + data.response[i].createdDate + "</td>")));
            tr.append($($("<td>" + data.response[i].updatedDate + "</td>")));
            tr.append($($("<td>" + data.response[i].show + "</td>")));

            table.append(tr);
            tr.append($($("<td><button class='update w3-button w3-tiny w3-blue w3-disabled'>Update</button></td>")));
            tr.append($($("<td><button class='delete w3-button w3-tiny w3-red w3-disabled'>Delete</button></td>")));
        }
    }
    if (type == "/getSubCategory") {
        console.log(data.response)
        for (var i = 0; i < data.response.length; i++) {
            var tr = $("<tr id='" + data.response[i]._id + "'></tr>");
            tr.append($($("<td>" + data.response[i].subC_ID + "</td>")));
            tr.append($($("<td>" + data.response[i].subC_NAME + "</td>")));
            tr.append($($("<td>" + data.response[i].SC_NAME + "</td>")));
            tr.append($($("<td>" + data.response[i].C_NAME + "</td>")));
            tr.append($($("<td>" + data.response[i].createdDate + "</td>")));
            tr.append($($("<td>" + data.response[i].updatedDate + "</td>")));
            tr.append($($("<td>" + data.response[i].show + "</td>")));

            table.append(tr);
            tr.append($($("<td><button class='update w3-button w3-tiny w3-blue w3-disabled'>Update</button></td>")));
            tr.append($($("<td><button class='delete w3-button w3-tiny w3-red w3-disabled'>Delete</button></td>")));
        }

    }


}


function createSelectionList(options, data, type) {
    options.empty();
    options.append("<option disabled='disabled' selected='true'>Choose your " + type + "</option>");
    for (var i = 0; i < data.length; i++) {
        if (type == "SuperCategory") {
            options.append("<option value='" + data[i].SC_NAME + "'>" + data[i].SC_NAME + "</option>");
        }
        if (type == "Category") {
            options.append("<option value='" + data[i].C_NAME + "'>" + data[i].C_NAME + "</option>");
        }

    }
}

function getTableData(table, type, header, option1, option2) {
    $.ajax({
        url: type,
        type: 'POST',
        data: {
            inputData1: option1,
            inputData2: option2
        },
        dataType: 'json',
        beforeSend: function () {
            // Show image container
            $(".loader").show();
        },
        success: function (data) {
            if (data.response.length > 0) {
                createTable(table, type, data, header);
                if (type == "/getSuperCategory") {
                    createSelectionList($('#tableByCategory'), data.response, "SuperCategory");
                }

            }
        },
        complete: function (data) {
            // Hide image container
            $(".loader").hide();
        }
    });
}
$(function () {
    //$('#addC').hide();
    $(".loader").hide();
    $('#tableBySubCategory').hide();
    getTableData($('#categoryTable'), "/getSuperCategory", superCategoryHeader, "", "");
    // getTableData($('#categoryTable'), "/getSubCategory", subCategoryHeader, "SuperCategory1","Category2")

    if ($('#showIDSC').prop('checked')) {
        $('#showIDSC').val('True');
    } else
        $('#showIDSC').val('False');

    if ($('#showIDC').prop('checked')) {
        $('#showIDC').val('True');
    } else
        $('#showIDC').val('False');


    if ($('#showIDSubC').prop('checked')) {
        $('#showIDSubC').val('True');
    } else
        $('#showIDSubC').val('False');


    $('#addSuperCat').click(function (e) {
        e.preventDefault();
        var formData = $('#addSCFORM').serialize();
        alert(formData);
        $.ajax({
            url: '/addSuperCategory',
            type: 'POST',
            dataType: 'json',
            data: formData,
            beforeSend: function () {
                // Show image container
                $(".loader").show();
            },
            success: function (data) {
                if (data.result == "Added") {
                    $('#superCategory').hide();
                    // $('#addC').show();
                }
            },
            complete: function (data) {
                // Hide image container
                $(".loader").hide();
            }
        });
    });
    $('#addC').click(function () {
        $.ajax({
            url: '/getSuperCategory',
            type: 'POST',
            dataType: 'json',
            beforeSend: function () {
                // Show image container
                $(".loader").show();
            },
            success: function (data) {
                if (data.response.length > 0) {
                    createSelectionList($('#S_CNAME'), data.response, "SuperCategory");
                }
            },
            complete: function (data) {
                // Hide image container
                $(".loader").hide();
            }
        });


    });

    $('#addCat').click(function () {
        var formData = $('#addCFORM').serialize();
        $.ajax({
            url: '/addCategory',
            type: 'POST',
            dataType: 'json',
            data: formData,
            beforeSend: function () {
                // Show image container
                $(".loader").show();
            },
            success: function (data) {
                if (data.result == "Added") {
                    $('#category').hide();
                }
            },
            complete: function (data) {
                // Hide image container
                $(".loader").hide();
            }
        });
    });


    $('#addsubC').click(function () {
        $('#sub_NAMESCID').empty();
        $.ajax({
            url: '/getSuperCategory',
            type: 'POST',
            dataType: 'json',
            beforeSend: function () {
                // Show image container
                $(".loader").show();
            },
            success: function (data) {
                if (data.response.length > 0) {
                    createSelectionList($('#sub_NAMESCID'), data.response, "SuperCategory");
                }
            },
            complete: function (data) {
                // Hide image container
                $(".loader").hide();
            }
        });
    });

    $('select#tableByCategory').change(function () {
        var superCategory = $(this).val();
        getTableData($('#categoryTable'), "/getCategory", categoryHeader, superCategory, "");
       
        $('#tableBySubCategory').empty();
        $.ajax({
            url: '/getCategory',
            type: 'POST',
            data: {
                inputData1: superCategory
            },
            dataType: 'json',
            success: function (data) {
                 $('#tableBySubCategory').show();
                if (data.response.length > 0) {
                    createSelectionList($('#tableBySubCategory'), data.response, "Category");
                }

            }
        });
        $('select#tableBySubCategory').change(function () {
            var category = $(this).val();
            getTableData($('#categoryTable'), "/getSubCategory", subCategoryHeader, superCategory, category);
        });

    });



    $('select#sub_NAMESCID').change(function () {
        $('#sub_NAMECID').empty();
        $.ajax({
            url: '/getCategory',
            type: 'POST',
            data: {
                inputData1: $(this).val()
            },
            dataType: 'json',
            beforeSend: function () {
                // Show image container
                $(".loader").show();
            },
            success: function (data) {
                if (data.response.length > 0) {
                    createSelectionList($('#sub_NAMECID'), data.response, "Category");
                }
            },
            complete: function (data) {
                // Hide image container
                $(".loader").hide();
            }
        });
    });

    $('#addSUBC').click(function (req, res) {
        var formData = $('#addsubCFORM').serialize();
        $.ajax({
            url: '/addSubCategory',
            type: 'POST',
            dataType: 'json',
            data: formData,
            beforeSend: function () {
                // Show image container
                $(".loader").show();
            },
            success: function (data) {
                if (data.result == "Added") {
                    $('#subCategory').hide();
                }
            },
            complete: function (data) {
                // Hide image container
                $(".loader").hide();
            }
        });
    });
    
    
    
});